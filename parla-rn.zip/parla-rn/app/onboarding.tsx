import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Svg, { Circle, Line, Path } from 'react-native-svg';
import { useAnalysis } from '../src/context/AnalysisContext';
import { CheckIcon, SunIcon } from '../src/components/icons';
import { PrimaryButton, type } from '../src/components/ui';
import { colors, fonts, radius } from '../src/theme';
import { KEYS } from '../src/storageKeys';

function Illustration() {
  return (
    <Svg width={342} height={270} viewBox="0 0 342 270" fill="none">
      <Circle cx="120" cy="100" r="54" fill={colors.sun} />
      <Path d="M120 22v14M120 164v14M42 100h14M184 100h14M65 45l10 10M165 145l10 10M65 155l10-10M165 55l10-10" stroke={colors.sun} strokeWidth={6} strokeLinecap="round" />
      <Path d="M230 96a26 26 0 0 1 50-6a20 20 0 0 1 8 39h-60a18 18 0 0 1 2-33z" fill={colors.rainSoft} stroke={colors.rain} strokeWidth={3} />
      <Path d="M244 142l-5 12M262 142l-5 12M280 142l-5 12" stroke={colors.rain} strokeWidth={3} strokeLinecap="round" />
      <Line x1="226" y1="80" x2="300" y2="164" stroke={colors.primary} strokeWidth={5} strokeLinecap="round" />
      <Path d="M60 238 h160 a12 12 0 0 0 12 -12 v-18 a10 10 0 0 0 -8 -10 l-30 -7 l-22 -24 a14 14 0 0 0 -11 -5 h-50 a14 14 0 0 0 -12 6 l-18 26 l-14 4 a9 9 0 0 0 -7 9 v19 a12 12 0 0 0 12 12 z" fill={colors.ink} />
      <Path d="M96 190 l12 -18 h42 l17 18 z" fill={colors.background} />
      <Circle cx="92" cy="240" r="16" fill={colors.ink} stroke={colors.peach} strokeWidth={4} />
      <Circle cx="194" cy="240" r="16" fill={colors.ink} stroke={colors.peach} strokeWidth={4} />
    </Svg>
  );
}

export default function Onboarding() {
  const { requestLocation } = useAnalysis();
  const [tracking, setTracking] = useState({ car: true, glass: true });
  const [busy, setBusy] = useState(false);

  const options: { key: 'car' | 'glass'; label: string }[] = [
    { key: 'car', label: 'Aracım' },
    { key: 'glass', label: 'Camlarım' },
  ];

  const start = async () => {
    setBusy(true);
    await requestLocation();
    await AsyncStorage.multiSet([
      [KEYS.onboarded, '1'],
      [KEYS.tracking, JSON.stringify(tracking)],
    ]);
    setBusy(false);
    router.replace('/');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.logoRow}>
          <View style={styles.logo}><SunIcon size={20} color={colors.ink} strokeWidth={2.2} /></View>
          <Text style={styles.logoText}>Parla</Text>
        </View>

        <View style={styles.hero}><Illustration /></View>

        <View style={{ gap: 10 }}>
          <Text style={styles.h1}>Yıkadın, ertesi gün yağmur mu yağdı?</Text>
          <Text style={[type.body, { color: colors.muted, fontSize: 16 }]}>
            Parla hava durumunu senin yerine izler; aracını yıkamak ve camlarını silmek için en doğru günü söyler.
          </Text>
        </View>

        <View style={{ gap: 10 }}>
          <Text style={[type.bodyBold, { fontSize: 14 }]}>Neyi takip edelim?</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {options.map((o) => {
              const on = tracking[o.key];
              return (
                <Pressable
                  key={o.key}
                  onPress={() => setTracking((t) => ({ ...t, [o.key]: !t[o.key] }))}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: on }}
                  style={[styles.option, { borderColor: on ? colors.primary : colors.border }]}
                >
                  {on && <CheckIcon />}
                  <Text style={[styles.optionText, { color: on ? colors.ink : colors.muted }]}>{o.label}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={{ marginTop: 'auto', gap: 12 }}>
          <PrimaryButton
            title="Konumuma göre başla"
            onPress={start}
            loading={busy}
            disabled={!tracking.car && !tracking.glass}
          />
          <Text style={[type.caption, { textAlign: 'center' }]}>Konumun yalnızca hava tahmini için kullanılır.</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  container: { flex: 1, paddingHorizontal: 24, paddingTop: 12, paddingBottom: 16, gap: 22 },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 36, height: 36, borderRadius: 12, backgroundColor: colors.sun, alignItems: 'center', justifyContent: 'center' },
  logoText: { fontFamily: fonts.display, fontSize: 22, color: colors.ink, letterSpacing: -0.4 },
  hero: { height: 290, borderRadius: 32, backgroundColor: colors.peach, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  h1: { fontFamily: fonts.display, fontSize: 32, lineHeight: 35, letterSpacing: -0.8, color: colors.ink },
  option: {
    flex: 1, height: 56, borderRadius: radius.md, borderWidth: 2, backgroundColor: colors.surface,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  optionText: { fontFamily: fonts.bodyBold, fontSize: 15 },
});
