import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAnalysis } from '../src/context/AnalysisContext';
import { BackIcon } from '../src/components/icons';
import { IconButton, PrimaryButton, StatusTag, type } from '../src/components/ui';
import { colors, fonts, radius } from '../src/theme';

export default function WhyScreen() {
  const { mode, results } = useAnalysis();
  const result = results[mode];
  const label = mode === 'car' ? 'Araç yıkama skoru' : 'Cam silme skoru';

  const goBack = () => (router.canGoBack() ? router.back() : router.replace('/'));

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <IconButton label="Geri" onPress={goBack}><BackIcon /></IconButton>
          <Text style={type.title}>Neden bugün?</Text>
        </View>

        {!result ? (
          <Text style={[type.body, { color: colors.muted }]}>Önce Bugün ekranından analiz yapmalısın.</Text>
        ) : (
          <>
            <View style={styles.scoreRow}>
              <View style={{ gap: 2 }}>
                <Text style={type.caption}>{label}</Text>
                <Text style={styles.bigScore}>{result.score}</Text>
              </View>
              {result.factors && (
                <View style={styles.countTag}>
                  <Text style={styles.countText}>
                    {result.factors.length} etkenden {result.factors.filter((f) => f.status === 'good').length}'i uygun
                  </Text>
                </View>
              )}
            </View>

            {result.factors && result.factors.length > 0 ? (
              <View style={styles.list}>
                {result.factors.map((f, i) => (
                  <View key={`${f.name}-${i}`} style={[styles.factor, i < result.factors!.length - 1 && styles.factorBorder]}>
                    <View style={{ flex: 1 }}>
                      <Text style={type.bodyBold}>{f.name}</Text>
                      <Text style={type.caption}>{f.value}</Text>
                    </View>
                    <StatusTag status={f.status} />
                  </View>
                ))}
              </View>
            ) : (
              <View style={styles.card}>
                <Text style={type.caption}>Hava özeti</Text>
                <Text style={type.bodyBold}>{result.todaySummary}</Text>
                <Text style={[type.body, { color: colors.muted }]}>{result.reason}</Text>
              </View>
            )}

            {result.tip && (
              <View style={styles.tip}>
                <Text style={styles.tipLabel}>İpucu</Text>
                <Text style={styles.tipText}>{result.tip}</Text>
              </View>
            )}

            <PrimaryButton title="Hatırlatma kur" onPress={() => router.navigate('/reminders')} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 32, gap: 16 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  scoreRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', paddingHorizontal: 4 },
  bigScore: { fontFamily: fonts.display, fontSize: 56, lineHeight: 60, letterSpacing: -1.5, color: colors.primary },
  countTag: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, backgroundColor: colors.peach },
  countText: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.peachText },
  list: { borderRadius: radius.lg, backgroundColor: colors.surface, paddingHorizontal: 16, paddingVertical: 4 },
  factor: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  factorBorder: { borderBottomWidth: 1, borderBottomColor: colors.surfaceMuted },
  card: { padding: 18, borderRadius: radius.lg, backgroundColor: colors.surface, gap: 6 },
  tip: { padding: 18, borderRadius: radius.lg, backgroundColor: colors.ink, gap: 6 },
  tipLabel: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.sunSoft },
  tipText: { fontFamily: fonts.body, fontSize: 15, lineHeight: 22, color: colors.background },
});
