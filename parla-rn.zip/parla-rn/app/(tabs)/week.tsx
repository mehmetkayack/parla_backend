import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAnalysis } from '../../src/context/AnalysisContext';
import { Mode, WeekDay } from '../../src/services/api';
import { CloudIcon, RainIcon, SunIcon } from '../../src/components/icons';
import { PrimaryButton, SegmentedControl, type } from '../../src/components/ui';
import { colors, fonts, radius } from '../../src/theme';

const MODE_OPTIONS: { value: Mode; label: string }[] = [
  { value: 'car', label: 'Araç' },
  { value: 'glass', label: 'Cam' },
];

function WeatherIcon({ condition }: { condition: WeekDay['condition'] }) {
  if (condition === 'rain') return <RainIcon size={24} />;
  if (condition === 'cloud') return <CloudIcon size={24} />;
  return <SunIcon size={24} color={colors.sun} />;
}

function DayRow({ d, last }: { d: WeekDay; last: boolean }) {
  const rainy = d.condition === 'rain';
  const barColor = colors.sun;
  return (
    <View style={[styles.row, !last && styles.rowBorder]}>
      <View style={{ width: 48 }}>
        <Text style={type.bodyBold}>{d.day}</Text>
        {d.temp && <Text style={type.caption}>{d.temp}</Text>}
      </View>
      <View style={{ width: 28, alignItems: 'center' }}><WeatherIcon condition={d.condition} /></View>
      <View style={{ flex: 1 }}>
        {rainy ? (
          <View style={styles.waitTag}><Text style={styles.waitText}>Bekle</Text></View>
        ) : (
          <View style={styles.track}>
            <View style={[styles.bar, { width: `${Math.max(0, Math.min(100, d.score))}%`, backgroundColor: barColor }]} />
          </View>
        )}
      </View>
      <Text style={[type.bodyBold, { width: 32, textAlign: 'right' }]}>{rainy ? '—' : d.score}</Text>
    </View>
  );
}

export default function WeekScreen() {
  const { mode, setMode, results } = useAnalysis();
  const result = results[mode];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={type.display}>Bu hafta</Text>
        <SegmentedControl options={MODE_OPTIONS} value={mode} onChange={setMode} />

        {!result ? (
          <View style={styles.empty}>
            <Text style={type.title}>Önce bugünkü analizi yap</Text>
            <Text style={[type.body, { color: colors.muted }]}>
              Haftalık planı görmek için Bugün ekranında konumuna göre analizi başlat.
            </Text>
            <PrimaryButton title="Bugün ekranına git" onPress={() => router.navigate('/')} />
          </View>
        ) : (
          <>
            <View style={styles.best}>
              <View style={styles.bestIcon}><SunIcon size={24} color={colors.ink} /></View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={[type.caption, { color: colors.peachText, fontFamily: fonts.bodySemi }]}>Haftanın en iyi günü</Text>
                <Text style={[type.bodyBold, { fontSize: 17 }]}>{result.bestDay}</Text>
              </View>
            </View>

            {result.week && result.week.length > 0 ? (
              <View style={styles.list}>
                {result.week.map((d, i) => (
                  <DayRow key={`${d.day}-${i}`} d={d} last={i === result.week!.length - 1} />
                ))}
              </View>
            ) : (
              <View style={styles.empty}>
                <Text style={[type.body, { color: colors.muted }]}>{result.todaySummary}</Text>
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 32, gap: 14 },
  best: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderRadius: radius.lg, backgroundColor: colors.peach },
  bestIcon: { width: 48, height: 48, borderRadius: 16, backgroundColor: colors.sun, alignItems: 'center', justifyContent: 'center' },
  list: { borderRadius: radius.lg, backgroundColor: colors.surface, paddingHorizontal: 16, paddingVertical: 4 },
  row: { height: 62, flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: colors.surfaceMuted },
  track: { height: 8, borderRadius: 4, backgroundColor: colors.surfaceMuted, overflow: 'hidden' },
  bar: { height: 8, borderRadius: 4 },
  waitTag: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, backgroundColor: colors.rainSoft },
  waitText: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.rain },
  empty: { padding: 20, borderRadius: radius.lg, backgroundColor: colors.surface, gap: 12 },
});
