import React, { useEffect, useState } from 'react';
import { Redirect, Tabs } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BellIcon, CalendarIcon, SunIcon } from '../../src/components/icons';
import { colors, fonts } from '../../src/theme';
import { KEYS } from '../../src/storageKeys';

export default function TabsLayout() {
  const [onboarded, setOnboarded] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(KEYS.onboarded)
      .then((v) => setOnboarded(v === '1'))
      .catch(() => setOnboarded(true));
  }, []);

  if (onboarded === null) return null;
  if (!onboarded) return <Redirect href="/onboarding" />;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border, height: 84, paddingTop: 8 },
        tabBarLabelStyle: { fontFamily: fonts.bodySemi, fontSize: 12 },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{ title: 'Bugün', tabBarIcon: ({ color }) => <SunIcon color={color} /> }}
      />
      <Tabs.Screen
        name="week"
        options={{ title: 'Hafta', tabBarIcon: ({ color }) => <CalendarIcon color={color} /> }}
      />
      <Tabs.Screen
        name="reminders"
        options={{ title: 'Hatırlatmalar', tabBarIcon: ({ color }) => <BellIcon color={color} /> }}
      />
    </Tabs>
  );
}
