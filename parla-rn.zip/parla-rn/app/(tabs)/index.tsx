import React from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAnalysis } from '../../src/context/AnalysisContext';
import { Mode } from '../../src/services/api';
import { BellIcon } from '../../src/components/icons';
import {
  IconButton, PrimaryButton, ScoreRing, SecondaryButton, SegmentedControl, WeatherChip, scoreTag, type,
} from '../../src/components/ui';
import { colors, fonts, radius } from '../../src/theme';

const MODE_OPTIONS: { value: Mode; label: string }[] = [
  { value: 'car', label: 'Araç' },
  { value: 'glass', label: 'Cam' },
];

export default function TodayScreen() {
  const { mode, setMode, locationName, locationError, results, loading, errorMsg, runAnalysis } = useAnalysis();
  const result = results[mode];
  const isLoading = loading[mode];

  const analyze = async () => {
    const status = await runAnalysis(mode);
    if (status === 'limit') {
      Alert.alert(
        'Günlük analiz hakkın doldu',
        'Bir reklam izleyerek yeni hak kazanabilir ya da Premium ile sınırsız analiz yapabilirsin.',
        [
          { text: 'Kapat', style: 'cancel' },
          { text: 'Premium', onPress: () => { /* Premium ekranına yönlendir */ } },
          { text: 'Reklam izle', onPress: () => { /* AdMob ödüllü reklam burada tetiklenecek */ } },
        ]
      );
    }
  };

  const modeWord = mode === 'car' ? 'aracını yıkamak' : 'camlarını silmek';

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Başlık */}
        <View style={styles.header}>
          <View style={{ gap: 2, flex: 1 }}>
            <Text style={type.caption} numberOfLines={1}>{locationName} · Bugün</Text>
            <Text style={[type.display, { fontSize: 26 }]}>{result?.weather?.temp ?? 'Hava durumu'}</Text>
          </View>
          <IconButton label="Hatırlatmalar" onPress={() => router.push('/reminders')}>
            <BellIcon />
          </IconButton>
        </View>

        {locationError && <Text style={[type.caption, { color: colors.rain }]}>{locationError}</Text>}

        <SegmentedControl options={MODE_OPTIONS} value={mode} onChange={setMode} />

        {/* Karar kartı */}
        <View style={styles.verdict}>
          {result ? (
            <>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 18 }}>
                <ScoreRing score={result.score} />
                <View style={{ flex: 1, gap: 6 }}>
                  <Text style={styles.verdictTag}>{scoreTag(result.score)}</Text>
                  <Text style={styles.verdictTitle}>{result.summary}</Text>
                </View>
              </View>
              <Text style={styles.verdictBody}>{result.reason}</Text>
              <View style={styles.verdictRow}>
                <Text style={styles.verdictRowLabel}>{result.bestWindow ? 'En iyi saat aralığı' : 'En ideal gün'}</Text>
                <Text style={styles.verdictRowValue}>{result.bestWindow ?? result.bestDay}</Text>
              </View>
            </>
          ) : (
            <>
              <Text style={styles.verdictTag}>Hava analizi</Text>
              <Text style={styles.verdictTitle}>Bugün {modeWord} için uygun mu?</Text>
              <Text style={styles.verdictBody}>
                {locationName} için yağmur, rüzgar, güneş ve toz tahminine bakıp sana net bir cevap verelim.
              </Text>
            </>
          )}
        </View>

        {/* Hava bilgileri */}
        {result?.weather ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {result.weather.rain && <WeatherChip label="Yağmur" value={result.weather.rain} />}
            {result.weather.wind && <WeatherChip label="Rüzgar" value={result.weather.wind} />}
            {result.weather.uv && <WeatherChip label="UV" value={result.weather.uv} />}
          </View>
        ) : result ? (
          <View style={styles.summaryCard}>
            <Text style={type.caption}>Hava özeti</Text>
            <Text style={type.bodyBold}>{result.todaySummary}</Text>
          </View>
        ) : null}

        {errorMsg && <Text style={[type.caption, { color: colors.rain }]}>{errorMsg}</Text>}

        {/* Eylemler */}
        {result ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <SecondaryButton title="Neden?" onPress={() => router.push('/why')} style={{ flex: 1 }} />
            <PrimaryButton title="Yeniden analiz et" onPress={analyze} loading={isLoading} style={{ flex: 2 }} />
          </View>
        ) : (
          <PrimaryButton title="Analiz et" onPress={analyze} loading={isLoading} />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 32, gap: 16 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  verdict: { padding: 22, borderRadius: radius.xl, backgroundColor: colors.ink, gap: 16 },
  verdictTag: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.sunSoft },
  verdictTitle: { fontFamily: fonts.displayBold, fontSize: 22, lineHeight: 26, color: colors.background },
  verdictBody: { fontFamily: fonts.body, fontSize: 15, lineHeight: 22, color: '#E9DDD0' },
  verdictRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 14, borderRadius: radius.md, backgroundColor: colors.inkSoft, gap: 12,
  },
  verdictRowLabel: { fontFamily: fonts.body, fontSize: 13, color: '#D9CBBB' },
  verdictRowValue: { fontFamily: fonts.bodyBold, fontSize: 16, color: colors.background, flexShrink: 1, textAlign: 'right' },
  summaryCard: { padding: 16, borderRadius: radius.lg, backgroundColor: colors.surface, gap: 4 },
});
