import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { Toggle, type } from '../../src/components/ui';
import { colors, fonts, radius } from '../../src/theme';
import { KEYS } from '../../src/storageKeys';

type ReminderKey = 'goodDay' | 'rainAfterWash' | 'weeklyPlan' | 'glass';
type ReminderState = Record<ReminderKey, boolean>;

const REMINDERS: { key: ReminderKey; title: string; sub: string }[] = [
  { key: 'goodDay', title: 'Uygun gün gelince haber ver', sub: 'Skor 80 üstüne çıkınca sabah bildirimi' },
  { key: 'rainAfterWash', title: 'Yıkadıktan sonra yağmur uyarısı', sub: '48 saat içinde yağmur varsa önceden söyler' },
  { key: 'weeklyPlan', title: 'Haftalık plan', sub: 'Her pazar 19:00, haftanın en iyi günleri' },
  { key: 'glass', title: 'Cam silme hatırlatması', sub: 'Güneşin çekildiği saate göre' },
];

const DEFAULTS: ReminderState = { goodDay: true, rainAfterWash: true, weeklyPlan: true, glass: false };
const WEEKLY_ID = 'parla-weekly-plan';

async function ensurePermission() {
  const current = await Notifications.getPermissionsAsync();
  if (current.granted) return true;
  const asked = await Notifications.requestPermissionsAsync();
  return asked.granted;
}

async function setWeeklyPlan(on: boolean) {
  await Notifications.cancelScheduledNotificationAsync(WEEKLY_ID).catch(() => {});
  if (!on) return;
  await Notifications.scheduleNotificationAsync({
    identifier: WEEKLY_ID,
    content: { title: 'Haftanın planı hazır', body: 'Bu hafta yıkamak ve cam silmek için en iyi günlere bak.' },
    // weekday: 1 = Pazar (Expo'da hafta pazar günü başlar)
    trigger: { type: Notifications.SchedulableTriggerInputTypes.WEEKLY, weekday: 1, hour: 19, minute: 0 },
  });
}

function daysSince(iso: string | null) {
  if (!iso) return null;
  const diff = Date.now() - new Date(iso).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export default function RemindersScreen() {
  const [reminders, setReminders] = useState<ReminderState>(DEFAULTS);
  const [lastWash, setLastWash] = useState<string | null>(null);
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    (async () => {
      const [[, r], [, l], [, s]] = await AsyncStorage.multiGet([KEYS.reminders, KEYS.lastWash, KEYS.streak]);
      if (r) setReminders({ ...DEFAULTS, ...JSON.parse(r) });
      setLastWash(l);
      setStreak(s ? Number(s) : 0);
    })();
  }, []);

  const toggle = async (key: ReminderKey, value: boolean) => {
    if (value && !(await ensurePermission())) {
      Alert.alert('Bildirim izni kapalı', 'Hatırlatma alabilmek için telefon ayarlarından Parla bildirimlerini aç.');
      return;
    }
    const next = { ...reminders, [key]: value };
    setReminders(next);
    await AsyncStorage.setItem(KEYS.reminders, JSON.stringify(next));
    if (key === 'weeklyPlan') await setWeeklyPlan(value);
    // Diğer bildirimler hava verisine bağlı: backend push bildirimi ya da arka plan görevi ile gönderilmeli.
  };

  const markWashed = async () => {
    const since = daysSince(lastWash);
    if (since === 0) return; // bugün zaten işaretlendi
    const nextStreak = since !== null && since <= 14 ? streak + 1 : 1;
    const now = new Date().toISOString();
    setLastWash(now);
    setStreak(nextStreak);
    await AsyncStorage.multiSet([[KEYS.lastWash, now], [KEYS.streak, String(nextStreak)]]);
  };

  const since = daysSince(lastWash);
  const lastText = since === null ? 'Henüz kayıt yok' : since === 0 ? 'Bugün' : `${since} gün önce`;
  const doneToday = since === 0;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={type.display}>Hatırlatmalar</Text>

        <View style={styles.card}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View style={{ gap: 2 }}>
              <Text style={type.caption}>Son araç yıkaman</Text>
              <Text style={type.title}>{lastText}</Text>
            </View>
            <View style={{ gap: 2, alignItems: 'flex-end' }}>
              <Text style={type.caption}>Temiz seri</Text>
              <Text style={[type.title, { color: colors.primary }]}>{streak} kez</Text>
            </View>
          </View>
          <Pressable
            onPress={markWashed}
            disabled={doneToday}
            accessibilityRole="button"
            style={[styles.washButton, { backgroundColor: doneToday ? colors.peach : colors.ink }]}
          >
            <Text style={[styles.washText, { color: doneToday ? colors.peachText : colors.background }]}>
              {doneToday ? 'Kaydedildi, harika iş!' : 'Bugün yıkadım'}
            </Text>
          </Pressable>
        </View>

        <View style={styles.list}>
          {REMINDERS.map((r, i) => (
            <View key={r.key} style={[styles.row, i < REMINDERS.length - 1 && styles.rowBorder]}>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={type.bodyBold}>{r.title}</Text>
                <Text style={type.caption}>{r.sub}</Text>
              </View>
              <Toggle label={r.title} value={reminders[r.key]} onChange={(v) => toggle(r.key, v)} />
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 32, gap: 16 },
  card: { padding: 18, borderRadius: 24, backgroundColor: colors.surface, gap: 14 },
  washButton: { height: 50, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  washText: { fontFamily: fonts.bodyBold, fontSize: 16 },
  list: { borderRadius: 24, backgroundColor: colors.surface, paddingHorizontal: 18, paddingVertical: 4 },
  row: { minHeight: 72, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: colors.surfaceMuted },
});
