export const KEYS = {
  onboarded: 'parla:onboarded',
  tracking: 'parla:tracking',     // { car: boolean, glass: boolean }
  reminders: 'parla:reminders',   // hatırlatma anahtarları
  lastWash: 'parla:lastWash',     // ISO tarih
  streak: 'parla:streak',         // sayı (hafta)
};
