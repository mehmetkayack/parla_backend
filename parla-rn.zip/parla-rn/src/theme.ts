// Parla tasarım token'ları — tasarımdaki renkler, yazı tipleri ve ölçüler
export const colors = {
  background: '#FBF6EF',   // sıcak krem zemin
  surface: '#FFFFFF',      // kartlar
  surfaceMuted: '#F3E8DA', // segment kontrol zemini, çizgiler
  border: '#EFE4D6',
  ink: '#2A1F17',          // ana metin, koyu kart
  inkSoft: '#3A2C22',      // koyu kart içi kutu
  muted: '#6B5B4E',        // ikincil metin
  primary: '#C2501A',      // butonlar (beyaz metinle erişilebilir)
  primaryPressed: '#9E3F12',
  sun: '#F28C38',          // güneş, skor halkası, araç çubuğu
  sunSoft: '#F6A15A',      // koyu zemin üstü vurgu
  peach: '#FCE3CC',        // "İyi" etiketleri, öne çıkan kart
  peachText: '#7A3410',
  rain: '#2F5D7C',         // "Bekle" / yağmur durumu
  rainSoft: '#DCE8F0',
  switchOff: '#D9CBBB',
};

export const fonts = {
  display: 'BricolageGrotesque_800ExtraBold',
  displayBold: 'BricolageGrotesque_700Bold',
  body: 'Figtree_400Regular',
  bodyMedium: 'Figtree_500Medium',
  bodySemi: 'Figtree_600SemiBold',
  bodyBold: 'Figtree_700Bold',
};

export const radius = { sm: 12, md: 16, lg: 22, xl: 28, pill: 999 };
export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24 };
export const minTouch = 44;
