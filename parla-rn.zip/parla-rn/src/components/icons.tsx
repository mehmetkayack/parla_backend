import React from 'react';
import Svg, { Circle, Path, Rect } from 'react-native-svg';

type IconProps = { size?: number; color?: string; strokeWidth?: number };

const base = (size: number) => ({
  width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
});

export const SunIcon = ({ size = 22, color = '#2A1F17', strokeWidth = 2 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round">
    <Circle cx="12" cy="12" r="4" />
    <Path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
  </Svg>
);

export const CloudIcon = ({ size = 22, color = '#6B5B4E', strokeWidth = 2 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z" />
  </Svg>
);

export const RainIcon = ({ size = 22, color = '#2F5D7C', strokeWidth = 2 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M7 15h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 6.5 4.3 4.3 0 0 0 7 15z" />
    <Path d="M9 18l-1 3M13 18l-1 3M17 18l-1 3" />
  </Svg>
);

export const BellIcon = ({ size = 22, color = '#2A1F17', strokeWidth = 1.8 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
    <Path d="M10.3 21a1.9 1.9 0 0 0 3.4 0" />
  </Svg>
);

export const CalendarIcon = ({ size = 22, color = '#2A1F17', strokeWidth = 1.8 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Rect x="3" y="5" width="18" height="16" rx="2" />
    <Path d="M3 10h18M8 3v4M16 3v4" />
  </Svg>
);

export const BackIcon = ({ size = 20, color = '#2A1F17', strokeWidth = 2 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M15 5l-7 7 7 7" />
  </Svg>
);

export const CheckIcon = ({ size = 18, color = '#C2501A', strokeWidth = 2.4 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <Path d="M5 12l5 5L20 7" />
  </Svg>
);

export const WindIcon = ({ size = 20, color = '#C2501A', strokeWidth = 2 }: IconProps) => (
  <Svg {...base(size)} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round">
    <Path d="M3 8h11a3 3 0 1 0-3-3M3 12h16a3 3 0 1 1-3 3M3 16h8" />
  </Svg>
);
