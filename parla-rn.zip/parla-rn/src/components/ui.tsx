import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { colors, fonts, radius, minTouch } from '../theme';

// ---------- Yazı stilleri ----------
export const type = StyleSheet.create({
  display: { fontFamily: fonts.display, fontSize: 28, letterSpacing: -0.5, color: colors.ink },
  title: { fontFamily: fonts.displayBold, fontSize: 22, lineHeight: 26, color: colors.ink },
  body: { fontFamily: fonts.body, fontSize: 15, lineHeight: 22, color: colors.ink },
  bodyBold: { fontFamily: fonts.bodyBold, fontSize: 15, color: colors.ink },
  caption: { fontFamily: fonts.body, fontSize: 13, color: colors.muted },
});

// ---------- Skor halkası ----------
export function scoreTag(score: number) {
  if (score >= 80) return 'Harika gün';
  if (score >= 60) return 'Uygun';
  if (score >= 40) return 'Bekleyebilirsin';
  return 'Bugün değil';
}

export function ScoreRing({ score, size = 96 }: { score: number; size?: number }) {
  const stroke = 10;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, score));
  const ringColor = clamped >= 80 ? colors.sun : clamped >= 40 ? colors.sunSoft : '#7FA3BD';

  return (
    <View style={{ width: size, height: size }} accessibilityLabel={`Skor ${clamped} / 100`}>
      <Svg width={size} height={size}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke="#4A3A2E" strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2} cy={size / 2} r={r}
          stroke={ringColor} strokeWidth={stroke} fill="none" strokeLinecap="round"
          strokeDasharray={`${(c * clamped) / 100} ${c}`}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </Svg>
      <View style={[StyleSheet.absoluteFill, styles.center]}>
        <Text style={{ fontFamily: fonts.display, fontSize: 30, color: colors.background }}>{clamped}</Text>
        <Text style={{ fontFamily: fonts.body, fontSize: 11, color: '#D9CBBB' }}>/ 100</Text>
      </View>
    </View>
  );
}

// ---------- Araç / Cam seçici ----------
type Option<T extends string> = { value: T; label: string };

export function SegmentedControl<T extends string>({
  options, value, onChange,
}: { options: Option<T>[]; value: T; onChange: (v: T) => void }) {
  return (
    <View style={styles.segment}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <Pressable
            key={o.value}
            onPress={() => onChange(o.value)}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            style={[styles.segmentItem, active && styles.segmentItemActive]}
          >
            <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

// ---------- Butonlar ----------
export function PrimaryButton({
  title, onPress, loading, disabled, style,
}: { title: string; onPress: () => void; loading?: boolean; disabled?: boolean; style?: ViewStyle }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.primary,
        pressed && { backgroundColor: colors.primaryPressed },
        (disabled || loading) && { opacity: 0.6 },
        style,
      ]}
    >
      {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.primaryText}>{title}</Text>}
    </Pressable>
  );
}

export function SecondaryButton({ title, onPress, style }: { title: string; onPress: () => void; style?: ViewStyle }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [styles.secondary, pressed && { backgroundColor: colors.surfaceMuted }, style]}
    >
      <Text style={styles.secondaryText}>{title}</Text>
    </Pressable>
  );
}

export function IconButton({
  onPress, label, children,
}: { onPress: () => void; label: string; children: React.ReactNode }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={label} style={styles.iconButton}>
      {children}
    </Pressable>
  );
}

// ---------- Hava bilgisi kutucuğu ----------
export function WeatherChip({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.chip}>
      <Text style={type.caption}>{label}</Text>
      <Text style={[type.bodyBold, { fontSize: 16 }]}>{value}</Text>
    </View>
  );
}

// ---------- Durum etiketi ----------
export function StatusTag({ status }: { status: 'good' | 'warn' }) {
  const good = status === 'good';
  return (
    <View style={[styles.tag, { backgroundColor: good ? colors.peach : colors.rainSoft }]}>
      <Text style={[styles.tagText, { color: good ? colors.peachText : colors.rain }]}>{good ? 'İyi' : 'Dikkat'}</Text>
    </View>
  );
}

// ---------- Aç / kapa anahtarı ----------
export function Toggle({ value, onChange, label }: { value: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <Pressable
      onPress={() => onChange(!value)}
      accessibilityRole="switch"
      accessibilityState={{ checked: value }}
      accessibilityLabel={label}
      hitSlop={8}
      style={[styles.toggle, { backgroundColor: value ? colors.primary : colors.switchOff, alignItems: value ? 'flex-end' : 'flex-start' }]}
    >
      <View style={styles.toggleKnob} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center' },
  segment: {
    flexDirection: 'row', padding: 4, gap: 4, borderRadius: radius.md, backgroundColor: colors.surfaceMuted,
  },
  segmentItem: { flex: 1, height: minTouch, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' },
  segmentItemActive: { backgroundColor: colors.surface },
  segmentText: { fontFamily: fonts.bodySemi, fontSize: 15, color: colors.muted },
  segmentTextActive: { fontFamily: fonts.bodyBold, color: colors.ink },
  primary: {
    height: 56, borderRadius: 18, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  primaryText: { fontFamily: fonts.bodyBold, fontSize: 17, color: '#FFFFFF' },
  secondary: {
    height: 56, borderRadius: 18, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center',
  },
  secondaryText: { fontFamily: fonts.bodySemi, fontSize: 16, color: colors.ink },
  iconButton: {
    width: minTouch, height: minTouch, borderRadius: 14, backgroundColor: colors.surface,
    alignItems: 'center', justifyContent: 'center',
  },
  chip: {
    flex: 1, paddingVertical: 12, paddingHorizontal: 6, borderRadius: radius.md,
    backgroundColor: colors.surface, alignItems: 'center', gap: 4,
  },
  tag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  tagText: { fontFamily: fonts.bodyBold, fontSize: 12 },
  toggle: { width: 52, height: 32, borderRadius: 16, padding: 3, justifyContent: 'center' },
  toggleKnob: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#FFFFFF' },
});
