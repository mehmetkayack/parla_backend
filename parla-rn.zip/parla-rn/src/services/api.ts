import * as Application from 'expo-application';
import { Platform } from 'react-native';

// Telefonda test ederken bilgisayarının yerel IP'sini yaz (örn: http://192.168.1.X:3000)
export const API_URL = 'http://localhost:3000';

export type Mode = 'glass' | 'car';
export type Coords = { latitude: number; longitude: number };

export type WeekDay = {
  day: string;                       // "Cum", "Cmt"...
  temp?: string;                     // "23°"
  condition: 'sun' | 'cloud' | 'rain';
  score: number;                     // 0-100
};

export type Factor = {
  name: string;                      // "Yağmur"
  value: string;                     // "96 saat boyunca %5"
  status: 'good' | 'warn';
};

// Backend'in şu an döndürdüğü alanlar + ekranların kullanabileceği isteğe bağlı alanlar.
// İsteğe bağlı alanları backend'e eklediğinde ekranlar onları otomatik gösterir.
export type AnalysisResult = {
  todaySummary: string;
  bestDay: string;
  score: number;
  summary: string;
  reason: string;
  bestWindow?: string;               // "10:00 – 16:00"
  tip?: string;
  weather?: { temp?: string; rain?: string; wind?: string; uv?: string };
  week?: WeekDay[];
  factors?: Factor[];
};

export class LimitExceededError extends Error {
  constructor() {
    super('Günlük analiz hakkı doldu');
  }
}

export async function getDeviceID(): Promise<string> {
  if (Platform.OS === 'android') {
    return Application.getAndroidId() ?? 'android-default-id';
  }
  return (await Application.getIosIdForVendorAsync()) ?? 'ios-default-id';
}

export async function analyzeWeather(
  mode: Mode,
  locationName: string,
  coords: Coords
): Promise<AnalysisResult> {
  const endpoint = mode === 'glass' ? '/api/analyze-weather' : '/api/analyze-car-wash';
  const deviceIdentifier = await getDeviceID();

  const response = await fetch(`${API_URL}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ locationName, coords, deviceIdentifier }),
  });

  const data = await response.json();

  if (response.status === 403 && data?.limitExceeded) {
    throw new LimitExceededError();
  }
  if (!response.ok) {
    throw new Error(data?.error ?? `Sunucu hatası (${response.status})`);
  }
  return data as AnalysisResult;
}
