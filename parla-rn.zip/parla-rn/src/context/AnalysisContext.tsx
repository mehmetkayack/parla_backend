import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import * as Location from 'expo-location';
import {
  AnalysisResult,
  Coords,
  LimitExceededError,
  Mode,
  analyzeWeather,
} from '../services/api';

type RunStatus = 'ok' | 'limit' | 'error';

type AnalysisContextValue = {
  mode: Mode;
  setMode: (m: Mode) => void;
  locationName: string;
  coords: Coords;
  locationError: string | null;
  requestLocation: () => Promise<void>;
  results: Record<Mode, AnalysisResult | null>;
  loading: Record<Mode, boolean>;
  errorMsg: string | null;
  runAnalysis: (m: Mode) => Promise<RunStatus>;
};

// Varsayılan konum: Ayvalık / Balıkesir
const DEFAULT_COORDS: Coords = { latitude: 39.319, longitude: 26.6936 };

const AnalysisContext = createContext<AnalysisContextValue | null>(null);

export function AnalysisProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<Mode>('glass');
  const [locationName, setLocationName] = useState('Ayvalık, Balıkesir');
  const [coords, setCoords] = useState<Coords>(DEFAULT_COORDS);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [results, setResults] = useState<Record<Mode, AnalysisResult | null>>({ glass: null, car: null });
  const [loading, setLoading] = useState<Record<Mode, boolean>>({ glass: false, car: false });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const readPosition = useCallback(async () => {
    try {
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const next = { latitude: location.coords.latitude, longitude: location.coords.longitude };
      setCoords(next);

      const geo = await Location.reverseGeocodeAsync(next);
      if (geo.length > 0) {
        const place = geo[0];
        const city = place.city || place.region || '';
        const district = place.subregion || place.district || '';
        setLocationName(district && city ? `${district}, ${city}` : city || district || 'Konumum');
      }
      setLocationError(null);
    } catch (e) {
      console.error('Konum hatası:', e);
      setLocationError('Konum alınamadı. Varsayılan konum kullanılıyor.');
    }
  }, []);

  // Onboarding'deki "Konumuma göre başla" butonu bunu çağırır
  const requestLocation = useCallback(async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setLocationError('Konum izni verilmedi. Varsayılan konum kullanılıyor.');
      return;
    }
    await readPosition();
  }, [readPosition]);

  // İzin daha önce verildiyse açılışta sessizce konumu güncelle
  useEffect(() => {
    (async () => {
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status === 'granted') await readPosition();
    })();
  }, [readPosition]);

  const runAnalysis = useCallback(
    async (m: Mode): Promise<RunStatus> => {
      setLoading((l) => ({ ...l, [m]: true }));
      setErrorMsg(null);
      try {
        const data = await analyzeWeather(m, locationName, coords);
        setResults((r) => ({ ...r, [m]: data }));
        return 'ok';
      } catch (e) {
        if (e instanceof LimitExceededError) return 'limit';
        setErrorMsg('Sunucuya bağlanılamadı. İnternet bağlantını kontrol edip tekrar dene.');
        return 'error';
      } finally {
        setLoading((l) => ({ ...l, [m]: false }));
      }
    },
    [locationName, coords]
  );

  return (
    <AnalysisContext.Provider
      value={{
        mode, setMode, locationName, coords, locationError, requestLocation,
        results, loading, errorMsg, runAnalysis,
      }}
    >
      {children}
    </AnalysisContext.Provider>
  );
}

export function useAnalysis() {
  const ctx = useContext(AnalysisContext);
  if (!ctx) throw new Error('useAnalysis, AnalysisProvider içinde kullanılmalı');
  return ctx;
}
